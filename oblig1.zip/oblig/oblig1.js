//Oppgave 1
let utskriftOppg1 = document.getElementById("utskriftOppg1");



//Oppgave 2
let utskriftOppg2 = document.querySelector("");

//Oppgave 3

let knappOppg3 = document.querySelector("#btnOppg3")
knappOppg3.addEventListener("click", oppg3)

function oppg3() {

}

//Oppgave 4


//Oppgave 5